#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
char inf[100],pof[100],op[100];
int t=-1;

int isp(char c)
{
	switch(c)
	{
		case '+':
		{
			return 2;
			break;
		}
		case '-':
                {
                        return 2;
                        break;
                }

		case '*':
		{
			return 4;
			break;
		}
		case '/':
                {
                        return 4;
                        break;
                }

		case '^':
		{
			return 5;
			break;
		}
	}
}
int icp(char c)
{
        switch(c)
        {
		case '+':
                {
                        return 1;
                        break;
                }
                case '-':
                {
                        return 1;
                        break;
                }

                case '*':
                {
                        return 3;
                        break;
                }
                case '/':
                {
                        return 3;
                        break;
                }

                case '^':
                {
                        return 6;
                        break;
                }
        }
}
void push(char c)
{
		op[++t]=c;
}
char pop()
{
	char item=op[t--];
	return item;
}
void convintopost()
{
	int i=-1,j=-1;
	while(inf[++i]!='\0')
	{
		if(isalpha(inf[i])!=0)
			pof[++j]=inf[i];
		else if(inf[i]==')')
		{
			while(op[t]!='(')
				pof[++j]=pop();
			pop();
		}
		else
		{
			while(isp(op[t])>=icp(inf[i]))
				pof[++j]=pop();
			push(inf[i]);
		}
	}
	while(t!=-1)
		pof[++j]=pop();
}
void main()
{
	gets(inf);
	convintopost();
	printf("\n%s",pof);

}


