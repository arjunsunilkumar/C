#include<stdio.h>.
struct node
{
	int data;
	struct node* next;
};
struct node* head;
void insert(struct node* head)
{
	printf("\n1.Insert at Beginning\n2.Insert at End\n3.After a data");
	int c;
	scanf("%d",&c);
	switch(c)
	{
		case 1:
		{
			struct node* temp=(struct node*)malloc(sizeof(struct node));
			scanf("%d",temp->data);
			temp->next=head;
			head=temp;
	}
