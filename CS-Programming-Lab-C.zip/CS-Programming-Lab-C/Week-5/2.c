#include<stdio.h>
#include<string.h>
int main()
{
        char a[30][30],b[900],c[30];
	printf("Enter the string ");
	gets(b);
	int i=0,j=0,k=0,f=0;
	while(b[i]!='\0')
	{
		if(b[i]==' ')
		{
			j++;
			k=0;
		}
		else
		{
			a[j][k]=b[i];
			k++;
		}
		i++;
	}
	printf("Enter the substring to replace ");
        scanf("%s",c);
        for(int i=0;i<=j;i++)
        {
                if(strcmp(a[i],c)==0)
                {
                        scanf("%s",a[i]);
			f=1;
                }
        }
	if(f==1)
	for(int i=0;i<k;i++)
                printf("%s ",a[i]);
	else
		printf("Not found\n");
        return 0;

}
