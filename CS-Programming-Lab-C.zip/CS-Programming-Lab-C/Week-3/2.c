#include<stdio.h>
int main()
{
	int r,c=1,space,i,j;
	printf("Enter the no.of rows ");
	scanf("%d",&r);
	for(i=0;i<r;i++)
	{
		printf(" ");
		for(j=0;j<=i;j++)
		{
			if(j==0||i==0)
				c=i;
			else
				c=c+(i-j+1)/j;
			printf("%d",c);
		}
		printf("\n");
	}
}
