#include<stdio.h>

int main()
{
 int a,b,c;
 scanf("%d",&a);
c=a;
 b=a%10;
 a=a/10;
 while(a!=0)
 {
  b=b*10+(a%10);
  a=a/10;
 }
 printf("%d",b);
if(b==c)
	printf("\nPalindrome");
else
	printf("\nNot Palindrome");
 return 0;
}
