#include<stdio.h>
void main()
{
 float r,a,c;
 printf("Enter the value for radius");
 scanf("%f",&r);
 a=3.14*r*r;
 c=2*3.14*r;
 printf("Area of circle is %f and circumference is %f",a,c);
}

