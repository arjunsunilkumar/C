#include<stdio.h>
void main()
{
	float a,c;
	printf("enter the number ");
	int b;
	scanf("%f",&a);
	b=a;
	c=a-b;
	printf("The integer part is %d and fractional part is %f",b,c);
}
