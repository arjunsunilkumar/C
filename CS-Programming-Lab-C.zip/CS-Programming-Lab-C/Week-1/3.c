#include<stdio.h>
void main()
{
	float c,f;
	printf("Enter the temp in celcius ");
	scanf("%f",&c);
	f=9*c/5+32;
	printf("Corresponding temp in fahrenheit is %f",f);
}
