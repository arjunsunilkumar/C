#include<stdio.h>
void main()
{
	int a;
	scanf("%d",&a);
	if(a%7==0)
		printf("%d is divisible by 7",a);
	else
		printf("%d is not divisible by 7",a);
}
